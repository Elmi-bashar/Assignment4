// api/data.js
const express = require('express');
const router = express.Router();

const data = [
  {
    id: 1,
    firstname: 'Tim',
    surname: 'Berners-Lee'
  },
  {
    id: 2,
    firstname: 'Roy',
    surname: 'Fielding'
  }
];

router.get('/', (req, res) => {
  res.status(200).json(data);
});

module.exports = router;
